Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "cmd /c ApexShift_App.bat", 0, False
