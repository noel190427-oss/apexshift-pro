@echo off
title ApexShift Pro - Standalone App
cd /d "%~dp0"

echo ====================================================================
echo   ApexShift Pro - Forza Telemetrie App
echo ====================================================================

:: 1. Server im Hintergrund starten (falls noch nicht laeuft)
powershell -Command "try { $null = Invoke-RestMethod 'http://127.0.0.1:5305/api/telemetry' -TimeoutSec 1 } catch { Start-Process -WindowStyle Hidden -FilePath 'node' -ArgumentList 'server.mjs' }"

:: 2. Lenkrad-Bridge im Hintergrund starten
powershell -Command "if (-not (Get-Process python -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -like '*logitech_hardware_bridge*' })) { Start-Process -WindowStyle Hidden -FilePath 'python' -ArgumentList '-u','logitech_hardware_bridge.py','--host=127.0.0.1' }"

:: 3. Kurz warten bis Server bereit ist
timeout /t 1 /nobreak >nul

:: 4. Dashboard als echte native Windows-App starten (randloses App-Fenster ohne Browser-Tabs/URL-Leiste)
set APP_URL=http://localhost:5305
set WINDOW_FLAGS=--app=%APP_URL% --window-size=1280,820 --window-position=100,80

if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
  start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" %WINDOW_FLAGS%
  goto DONE
)

if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
  start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" %WINDOW_FLAGS%
  goto DONE
)

if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
  start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" %WINDOW_FLAGS%
  goto DONE
)

if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
  start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" %WINDOW_FLAGS%
  goto DONE
)

:: Fallback falls weder Edge noch Chrome verfuegbar ist
start "" "%APP_URL%"

:DONE
exit /b
