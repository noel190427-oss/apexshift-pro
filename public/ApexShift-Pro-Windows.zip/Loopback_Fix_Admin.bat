@echo off
title Forza Horizon Telemetrie Loopback Freischaltung
echo =========================================================
echo   Forza Horizon - UWP Loopback Freischaltung (Admin)
echo =========================================================
echo.
echo Schalte Telemetrie fuer Forza Horizon 4, 5 und 6 frei...
echo.

CheckNetIsolation.exe LoopbackExempt -a -n=Microsoft.ForteBaseGame_8wekyb3d8bbwe
CheckNetIsolation.exe LoopbackExempt -a -n=Microsoft.624F8B84B80_8wekyb3d8bbwe
CheckNetIsolation.exe LoopbackExempt -a -n=Microsoft.SunriseBaseGame_8wekyb3d8bbwe

echo.
echo =========================================================
echo ERFOLGREICH FREIGESCHALTET!
echo Jetzt kann Forza Horizon die Telemetriedaten an deinen PC senden!
echo =========================================================
echo.
pause
